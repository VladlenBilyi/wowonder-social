<?php
$themeName = 'WoWonder';

$themeFolder = 'wowonder';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:deendoughouz@gmail.com';

$themeVirsion = '1.2';

$themeImg = $wo['config']['theme_url'] . '/themeLogo.png';
?>