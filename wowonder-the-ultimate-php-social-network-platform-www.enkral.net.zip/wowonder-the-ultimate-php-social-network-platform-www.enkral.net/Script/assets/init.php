<?php
date_default_timezone_set('UTC');
session_start();
require_once('includes/cache.php');
require_once('includes/general.php');
require_once('includes/emo.php');
require_once('includes/tabels.php');
require_once('includes/core.php');