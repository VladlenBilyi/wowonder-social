<?php
$wo['description'] = '';
$wo['keywords']    = '';
$wo['page']        = '404';
$wo['title']       = '404, Page not avalibale';
$wo['content']     = Wo_LoadPage('404/content');