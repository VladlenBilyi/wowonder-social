<?php 
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (WoWonder)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/wowondersocial
// | @author_email: deendoughouz@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - A Social Networking Platform
// | Copyright (c) 2015 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
require 'assets/init.php';
if (Wo_IsLogged() === true) {
    $update_last_seen = Wo_LastSeen($wo['user']['user_id']);
}
$page = '';
if (!isset($_GET['tab1'])) {
    $page = 'welcome';
} elseif (isset($_GET['tab1'])) {
    $page = $_GET['tab1'];
}
switch ($page) {
    case 'home':
        include('sources/home.php');
        break;
    case 'welcome':
        include('sources/welcome.php');
        break;
    case 'activate':
        include('sources/activate.php');
        break;
    case 'search':
        include('sources/search.php');
        break;
    case 'timeline':
        include('sources/timeline.php');
        break;
    case 'pages':
        include('sources/my_pages.php');
        break;
    case 'page':
        include('sources/page.php');
        break;
    case 'create-page':
        include('sources/create_page.php');
        break;
    case 'setting':
        include('sources/setting.php');
        break;
    case 'page-setting':
        include('sources/page_setting.php');
        break;
    case 'messages':
        include('sources/messages.php');
        break;
    case 'logout':
        include('sources/logout.php');
        break;
    case '404':
        include('sources/404.php');
        break;
    case 'post':
        include('sources/story.php');
        break;
    case 'admin':
        include('sources/admin.php');
        break;
    case 'saved-posts':
        include('sources/savedPosts.php');
        break;
    case 'hashtag':
        include('sources/hashtag.php');
        break;
    case 'follow-requests':
        include('sources/followRequests.php');
        break;
    case 'terms':
        include('sources/term.php');
        break;
    case 'contact-us':
        include('sources/contact.php');
        break;
    /* API / Developers (will be available on future updates)
    case 'oauth':
        include('sources/oauth.php');
        break;
    case 'graph':
        include('sources/graph.php');
        break;
    case 'graph-success':
        include('sources/graph_success.php');
        break;
    case 'app-setting':
        include('sources/app_setting.php');
        break;
    case 'developers':
        include('sources/developers.php');
        break;
    case 'create-app':
        include('sources/create_app.php');
        break;
    case 'app':
        include('sources/app_page.php');
        break;
    case 'apps':
        include('sources/apps.php');
        break;
    */
}
if (empty($wo['content'])) {
    include('sources/404.php');
}
echo Wo_Loadpage('container');
//mysqli_close($sqlConnect);
?>