<?php

// user & account information table
define('T_USERS','Wo_Users');

// countries table
define('T_COUNTRIES', 'Wo_Countries');

// followers & friends table
define('T_FOLLOWERS', 'Wo_Followers');

// notifications table
define('T_NOTIFICATION', 'Wo_Notifications');

// messages & chat table
define('T_MESSAGES', 'Wo_Messages');

// block table (not active in v1.0)
define('T_BLOCKS', 'Wo_Blocks');

// posts table
define('T_POSTS', 'Wo_Posts');

// pinned posts table
define('T_PINNED_POSTS', 'Wo_PinnedPosts');

// post likes table
define('T_LIKES', 'Wo_Likes');

// saved posts table
define('T_SAVED_POSTS', 'Wo_SavedPosts');

// post wonders table
define('T_WONDERS', 'Wo_Wonders');

// comments table
define('T_COMMENTS', 'Wo_Comments');

// comment wonders table
define('T_COMMENT_WONDERS', 'Wo_CommentWonders');

// comment likes table
define('T_COMMENT_LIKES', 'Wo_CommentLikes');

// hashtag & trending table
define('T_HASHTAGS', 'Wo_Hashtags');

// post reports table
define('T_REPORTS', 'Wo_Reports');

// advertisements table
define('T_ADS', 'Wo_Ads');

// announcement table
define('T_ANNOUNCEMENT', 'Wo_Announcement');

// announcement views table
define('T_ANNOUNCEMENT_VIEWS', 'Wo_Announcement_Views');

// activities table
define('T_ACTIVITIES', 'Wo_Activities');

// apps table
define('T_APPS', 'Wo_Apps');

// apps permissions table
define('T_APPS_PERMISSION', 'Wo_Apps_Permission');

// tokens table
define('T_TOKENS', 'Wo_Tokens');

// activities table
define('T_PAGES', 'Wo_Pages');

// activities table
define('T_PAGES_LIKES', 'Wo_Pages_Likes');
?>