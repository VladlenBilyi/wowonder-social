<?php
$config['reCaptcha']  = "0";
$config['reCaptchaKey']    = "";
?>