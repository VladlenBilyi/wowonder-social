<?php
$config['user_lastseen']  = 1;
$config['age']    = 0;
$config['deleteAccount'] = 1;
$config['connectivitySystem']  = 0;
$config['profileVisit'] = "1";
$config['maxUpload']    = 1000000000;
$config['maxCharacters']    = 640;
$config['message_seen']    = 0;
$config['message_typing']    = 0;
$config['google_map_api']    = "AIzaSyBOfpaMO_tMMsuvS2T4zx4llbtsFqMuT9Y";
$config['allowedExtenstion'] = "jpg,png,jpeg,gif,docx,zip,rar,pdf,doc,mp3,mp4,wav,txt";
$config['censored_words'] = "";
?>