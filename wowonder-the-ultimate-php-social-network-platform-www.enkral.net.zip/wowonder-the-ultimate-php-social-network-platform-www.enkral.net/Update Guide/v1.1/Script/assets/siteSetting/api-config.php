<?php

$config['AllLogin']  = 1;
$config['googleLogin']     = 1;
$config['facebookLogin']   = 1;
$config['twitterLogin']    = 1;
$config['linkedinLogin']   = 1;
$config['VkontakteLogin']  = 1;

$config['facebookAppId']  = "";
$config['facebookAppKey'] = "";

$config['googleAppId']    = "";
$config['googleAppKey']   = "";

$config['twitterAppId']   = "";
$config['twitterAppKey']  = "";

$config['linkedinAppId']  = "";
$config['linkedinAppKey'] = "";

$config['VkontakteAppId']  = "";
$config['VkontakteAppKey'] = "";

?>