<?php 
require_once('siteSetting.config.php');
require_once('onOff.config.php');
require_once('reCaptcha.config.php');
require_once('userSetting.config.php');
require_once('googleAnalytics.config.php');
require_once('api-config.php');
require_once('theme.config.php');