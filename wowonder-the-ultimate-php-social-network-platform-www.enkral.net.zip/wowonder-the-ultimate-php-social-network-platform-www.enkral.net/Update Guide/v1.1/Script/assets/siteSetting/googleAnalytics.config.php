<?php
$config['googleAnalytics']  = "";
?>