<?php
$config['siteName']  = "";
$config['siteTitle']    = "WoWonder";
$config['siteKeywords']  = "";
$config['siteDesc']   = "";
$config['siteEmail']  = "info@wowonder.com";
$config['defualtLang'] = "english";
?>