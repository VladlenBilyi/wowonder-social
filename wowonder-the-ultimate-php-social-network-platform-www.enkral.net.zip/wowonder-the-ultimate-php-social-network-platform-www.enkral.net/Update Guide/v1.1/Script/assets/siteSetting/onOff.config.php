<?php
$config['emailValidation']  = 0;
$config['emailNotification'] = 0;
$config['fileSharing']    = 1;
$config['seoLink']    = 1;
$config['cacheSystem']    = 0;
$config['chatSystem']    = 1;
$config['useSeoFrindly']    = 1;
?>