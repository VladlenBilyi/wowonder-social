<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (WoWonder)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/wowondersocial
// | @author_email: deendoughouz@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - A Social Networking Platform
// | Copyright (c) 2015 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
// MySQL Hostname
$sql_db_host = "db_host";
// MySQL Database User
$sql_db_user = "db_user";
// MySQL Database Password
$sql_db_pass = "db_pass";
// MySQL Database Name
$sql_db_name = "db_name";

// Site URL
$site_url = "http://siteurl.com"; // e.g (http://www.example.com)