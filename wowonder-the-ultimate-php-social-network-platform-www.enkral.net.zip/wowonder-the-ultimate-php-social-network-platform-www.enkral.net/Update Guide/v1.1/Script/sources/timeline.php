<?php
if (isset($_GET['u'])) {
    if (Wo_UserExists($_GET['u']) === true && Wo_UserActive($_GET['u'])) {
        $user_id            = Wo_UserIdFromUsername($_GET['u']);
        $wo['user_profile'] = Wo_UserData($user_id);
    } else {
        header("Location: " . Wo_SeoLink('index.php?tab1=404'));
        exit();
    }
} else {
    header("Location: " . Wo_SeoLink('index.php?tab1=home'));
    exit();
}
if (Wo_IsLogged() === true && $wo['config']['profileVisit'] == 1) {
    if ($wo['user_profile']['user_id'] != $wo['user']['user_id']) {
        $notification_data_array = array(
            'recipient_id' => $wo['user_profile']['user_id'],
            'type' => 'visited_profile',
            'url' => 'index.php?tab1=timeline&u=' . $wo['user']['username']
        );
        Wo_RegisterNotification($notification_data_array);
    }
}
$wo['description'] = $wo['user_profile']['about'];
$wo['keywords']    = '';
$wo['page']        = 'timeline';
$wo['title']       = $wo['user_profile']['name'];
$wo['content']     = Wo_LoadPage('timeline/content');