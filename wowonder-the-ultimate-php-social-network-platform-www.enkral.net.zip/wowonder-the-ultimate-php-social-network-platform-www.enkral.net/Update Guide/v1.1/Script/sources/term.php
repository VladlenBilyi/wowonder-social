<?php
if (empty($_GET['type']) || !isset($_GET['type'])) {
	header("Location: " . Wo_SeoLink('index.php?tab1=home'));
	exit();
}
$pages = array('terms','privacy-policy','about-us','developers');
if (!in_array($_GET['type'], $pages)) {
	header("Location: " . Wo_SeoLink('index.php?tab1=home'));
	exit();
}
$wo['description'] = $wo['config']['siteDesc'];
$wo['keywords']    = $wo['config']['siteKeywords'];
$wo['page']        = 'terms';
$wo['title']       = '';
$type = Wo_Secure($_GET['type']);

if ($type == 'terms') {
	$wo['title']  = $wo['lang']['terms_of_use'];
} else if ($type == 'about-us') {
    $wo['title']  = $wo['lang']['about'];
} else if ($type == 'privacy-policy') {
    $wo['title']  = $wo['lang']['privacy_policy'];
} else if ($type == 'developers') {
    $wo['title']  = $wo['lang']['developers'];
}
$page = '';
if ($type == 'developers') {
	$page = 'terms/' . $type;
} else {
	$page = 'terms/' . $wo['language'] . '/' . $type;
}

$wo['title'] = $wo['config']['siteName'] . ' | ' . $wo['title'];
$wo['content']     = Wo_LoadPage($page);