current_notif_count = 0;

current_msg_count = 0;

current_followR_count = 0;

current_width = $(window).width();

document_title = document.title;


$(function () {

  $('[data-toggle="tooltip"]').tooltip();

  // open last active tab

  var url = document.location.toString();

  if(url.match('#')) {

    $('.nav-tabs a[href=#' + url.split('#')[1] + ']').tab('show');

  }

  $('.nav-tabs a').on('shown.bs.tab', function (e) {

    window.location.hash = e.target.hash;

    $('body').scrollTop(0);

  });

  // get interval updates every 7.5 secounds

  setInterval(function () {
    Wo_intervalUpdates();
  }, 7000);

  // get interval updates every 7.5 secounds

  setInterval(function () {
    Wo_UpdateLastSeen();
  }, 55000);


  // check if user still logged in every 3 secoundsupdate_lastseen

  setInterval(function () {
    Wo_IsLogged();
  }, 30000);

  //  dropdown won't close on click

  $('.dropdown-menu.request-list, .dropdown-menu.post-recipient, .dropdown-menu.post-options').click(function (e) {

    e.stopPropagation();

  });

  // Stick the home side bar if the screen width is > than 900

  if(current_width > 900) {

    $(window).scroll(function () {

      if($(document).scrollTop() > 1500) {

        $('#sidebar-sticky').addClass('Stick', 700);

      } else {

        $('#sidebar-sticky').removeClass('Stick', 700);

      }

    });

  }

});


// update user last seen

function Wo_UpdateLastSeen() {
  $.get(Wo_Ajax_Requests_File(), {
    f: 'update_lastseen'
  });
}
// js function

function Wo_CheckUsername(username) {

  var check_container = $('.checking');

  var check_input = $('#username').val();
  if(check_input == '') {
    check_container.empty();
    return false;
  }

  check_container.removeClass('unavailable').removeClass('available').html('<i class="fa fa-clock-o"></i><span id="loading"> Checking <span>.</span><span>.</span><span>.</span></span>');


  $.get(Wo_Ajax_Requests_File(), {
    f: 'check_username',
    username: username
  }, function (data) {

    if(data.status == 200) {

      check_container.html('<i class="fa fa-check"></i> ' + data.message).removeClass('unavailable').addClass('available');

    } else if(data.status == 300) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 400) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 500) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 600) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    }

  });

}

function Wo_CheckPagename(pagename) {

  var check_container = $('.checking');

  var check_input = $('#page_name').val();
  if(check_input == '') {
    check_container.empty();
    return false;
  }

  check_container.removeClass('unavailable').removeClass('available').html('<i class="fa fa-clock-o"></i><span id="loading"> Checking <span>.</span><span>.</span><span>.</span></span>');


  $.get(Wo_Ajax_Requests_File(), {
    f: 'check_pagename',
    pagename: pagename
  }, function (data) {

    if(data.status == 200) {

      check_container.html('<i class="fa fa-check"></i> ' + data.message).removeClass('unavailable').addClass('available');

    } else if(data.status == 300) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 400) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 500) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    } else if(data.status == 600) {

      check_container.html('<i class="fa fa-remove"></i> ' + data.message).removeClass('available').addClass('unavailable');

    }

  });

}


// scroll to top function
function scrollToTop() {

  verticalOffset = typeof (verticalOffset) != 'undefined' ? verticalOffset : 0;

  element = $('html');

  offset = element.offset();

  offsetTop = offset.top;

  $('html, body').animate({
    scrollTop: offsetTop
  }, 300, 'linear');

}

// check if user is logged in function
function Wo_IsLogged() {

  $.post(Wo_Ajax_Requests_File() + '?f=session_status', function (data) {

    if(data.status == 200) {

      $('#logged-out-modal').modal({
        show: true
      });

    }

  });

}

// side bar users
function Wo_ReloadSideBarUsers() {

  Wo_progressIconLoader($('#sidebar-user-list-container').find('span'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'update_sidebar_users'
  }, function (data) {

    if(data.status == 200) {

      $('.sidebar-users-may-know-container').html(data.html);

    }

    Wo_progressIconLoader($('#sidebar-user-list-container').find('span'));

  });

}

// side bar pages
function Wo_ReloadSideBarPages() {

  Wo_progressIconLoader($('#sidebar-page-list-container').find('span'));
  
  var page_id = $('.sidebar-pages-may-know-container').find('.sidebar-page-data').attr('data-page-id');
  
  if (page_id == 'undefined') {
      page_id = '';
  }
  $.get(Wo_Ajax_Requests_File(), {
    f: 'pages',
    s: 'get_next_page',
    page_id: page_id
  }, function (data) {

    if(data.status == 200) {
      if (data.html.length == 0) {
        $('.sidebar-pages-may-know-container').html('<h2><div class="no-more-pages text-center">No more pages to like</div></h2>');
      } else {
        $('.sidebar-pages-may-know-container').hide().html(data.html).fadeIn(300);
      }
    }
    Wo_progressIconLoader($('#sidebar-page-list-container').find('span'));
  });
}



// register user follow
function Wo_RegisterFollow(id) {

  element = $('.user-follow-button #Follow-' + id);

  Wo_progressIconLoader(element);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'follow_user',
    following_id: id
  }, function (data) {

    if(data.status == 200) {

      element.after(data.html);

      element.remove();

    }

  });

}

// register user follow
function Wo_RegisterPageLike(id) {

  element = $('.user-follow-button #like-' + id);

  Wo_progressIconLoader(element);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'like_page',
    page_id: id
  }, function (data) {

    if(data.status == 200) {

      if ($('.sidebar-listed-page-like-btn').attr('data-type') == "sidebar") {
        setTimeout(function () {
          Wo_ReloadSideBarPages();
        }, 500);
      }

      element.after(data.html);

      element.remove();

    }

  });

}

// get new notifications
function Wo_OpenNotificationsMenu() {

  notification_container = $('.notification-container');

  notification_list = $('#notification-list');

  Wo_progressIconLoader(notification_container.find('.notification-loading-progress'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'get_notifications'
  }, function (data) {

    if(data.status == 200) {

      if(data.html.length == 0) {

        notification_list.html('<span class="center-text padding-10">' + data.message + '</span>');

      } else {

        notification_list.html(data.html);

        Wo_intervalUpdates();

      }

    }

    Wo_progressIconLoader(notification_container.find('.notification-loading-progress'));

  });

}

// get new friend requests
function Wo_OpenRequestsMenu() {

  requests_container = $('.requests-container');

  requests_List = $('#requests-list');

  Wo_progressIconLoader(requests_container.find('.requests-loading'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'get_follow_requests'
  }, function (data) {

    if(data.status == 200) {

      if(data.html.length == 0) {

        requests_List.html('<span class="center-text">' + data.message + '</span>');

      } else {

        requests_List.html(data.html);

        Wo_intervalUpdates();

      }

    }

    Wo_progressIconLoader(requests_container.find('.requests-loading'));

  });

}

// Notifications & follow requests updates
function Wo_intervalUpdates() {

  var notification_container = $('.notification-container');

  var messages_notification_container = $('.messages-notification-container');

  var follow_requests_container = $('.requests-container');

  $.get(Wo_Ajax_Requests_File(), {
    f: 'send_interval'
  }, function (data) {

    if(typeof (data.notifications) != "undefined" && data.notifications > 0) {

      notification_container.find('.new-update-alert').removeClass('hidden');

      notification_container.find('.new-update-alert').text(data.notifications).show();

      if(data.notifications != current_notif_count) {

        notification_container.find('.fa-bell').addClass('faa-ring animated');

        document.getElementById('notification-sound').play();

        current_notif_count = data.notifications;

        setTimeout(function () {

          notification_container.find('.fa-bell').delay(1000).removeClass('faa-ring animated');

        }, 1700);

      }

    } else {

      notification_container.find('.new-update-alert').hide();

      current_notif_count = 0;
    }

    if(typeof (data.messages) != "undefined" && data.messages > 0) {

      messages_notification_container.find('.new-update-alert').removeClass('hidden');

      messages_notification_container.find('.new-update-alert').text(data.messages).show();

      if(data.messages != current_msg_count) {

        document.getElementById('message-sound').play();

        current_msg_count = data.messages;

      }

    } else {

      messages_notification_container.find('.new-update-alert').hide();

      current_msg_count = 0;

    }

    if(typeof (data.followRequests) != "undefined" && data.followRequests > 0) {

      follow_requests_container.find('.new-update-alert').removeClass('hidden');

      follow_requests_container.find('.new-update-alert').text(data.followRequests).show();

      if(data.followRequests != current_followR_count) {

        current_followR_count = data.followRequests;

      }

    } else {

      follow_requests_container.find('.new-update-alert').hide();

      current_followR_count = 0;

    }

    if(typeof (data.messages) != "undefined" && data.messages > 0 || typeof (data.notifications) != "undefined" && data.notifications > 0 || typeof (data.followRequests) != "undefined" && data.followRequests > 0) {

      title = Number(data.notifications) + Number(data.messages) + Number(data.followRequests);

      document.title = '(' + title + ') ' + document_title;

    } else {

      document.title = document_title;

    }

  });

}




// intervel new posts

function Wo_GetNewPosts() {

  var filter_by_more = $('#load-more-filter').find('.filter-by-more').attr('data-filter-by');

  if(filter_by_more != 'all') {

    return false;
  }

  if(typeof ($('#posts').attr('data-story-user')) == "string") {

    user_id = $('#posts').attr('data-story-user');

  } else {

    user_id = 0;

  }


  before_post_id = 0;

  if($('.post-container').length > 0) {

    var before_post_id = $('.post-container  > .post').attr('data-post-id');

  }

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'get_new_posts',
    before_post_id: before_post_id,
    user_id: user_id
  }, function (data) {

    if(data.status == 200) {

      if(data.html.length != 0) {

        $('#posts').find('.posts-container').remove();

      }

      $('#posts').prepend(data.html);

    }

  });

}

// load more posts
function Wo_GetMorePosts() {

  var more_posts = $('#load-more-posts');

  var filter_by_more = $('#load-more-filter').find('.filter-by-more').attr('data-filter-by');

  var after_post_id = $('.post:last').attr('data-post-id');

  var page_id = 0;

  var user_id = 0;

  if(after_post_id != null) {

    more_posts.show();

  }

  if(typeof ($('#posts').attr('data-story-user')) == "string") {

    user_id = $('#posts').attr('data-story-user');

  } else if(typeof ($('#posts').attr('data-story-page')) == "string") {

    page_id = $('#posts').attr('data-story-page');

  } else {

    user_id = 0;

  }

  Wo_progressIconLoader($('#load-more-posts'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'load_more_posts',
    filter_by_more: filter_by_more,
    after_post_id: after_post_id,
    user_id: user_id,
    page_id: page_id
  }, function (data) {

    if(data.status == 300) {

      more_posts.html('<span class="btn btn-default">' + data.text + '<span>');

    } else {

      $('#posts').append(data.html);

    }

    Wo_progressIconLoader($('#load-more-posts'));

  });

}

// post filteration
function Wo_FilterPostBy(filter_by) {

  var more_posts = $('#load-more-posts');

  var filter_by_more = $('#load-more-filter').find('.filter-by-more');

  filter_by_more.attr("data-filter-by", filter_by);

  var filter_by_progress_icon = $('.filter-container').find('.type-' + filter_by);

  Wo_progressIconLoader(filter_by_progress_icon);

  var page = 'false';

  if(typeof ($('#posts').attr('data-story-user')) == "string") {

    user_id = $('#posts').attr('data-story-user');

  } else if(typeof ($('#posts').attr('data-story-page')) == "string") {

    user_id = $('#posts').attr('data-story-page');

    page = 'true';

  } else {

    user_id = 0;

  }

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'filter_posts',
    filter_by: filter_by,
    user_id: user_id,
    page: page
  }, function (data) {

    if(data.status == 200) {

      $('#posts').html(data.html);

      more_posts.html('<span class="btn btn-default">' + data.text + '<span>');

    }

    Wo_progressIconLoader(filter_by_progress_icon);

  });

}

// register post like
function Wo_RegisterLike(post_id) {

  var post = $('#post-' + post_id);

  Wo_progressIconLoader(post.find('#like-button'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'register_like',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      post.find("[id^=like-button]").html('<i class="fa fa-thumbs-up progress-icon active-like" data-icon="thumbs-up"></i>');

      post.find("[id^=likes]").text(data.likes);

    } else {

      post.find("[id^=like-button]").html('<i class="fa fa-thumbs-up progress-icon" data-icon="thumbs-up"></i>');

      post.find("[id^=likes]").text(data.likes);

    }

  });

}

// register post wonder
function Wo_RegisterWonder(post_id) {

  var post = $('#post-' + post_id);

  Wo_progressIconLoader(post.find('#wonder-button'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'register_wonder',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      post.find("[id^=wonder-button]").html('<i class="fa fa-exclamation-circle progress-icon active-wonder" data-icon="exclamation-circle"></i>');

      post.find("[id^=wonders]").text(data.wonders);

    } else {

      post.find("[id^=wonder-button]").html('<i class="fa fa-exclamation-circle progress-icon" data-icon="exclamation-circle"></i>');

      post.find("[id^=wonders]").text(data.wonders);

    }

  });

}

// register post share
function Wo_RegisterShare(post_id) {

  var post = $('#post-' + post_id);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'register_share',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      post.find("#share-button").addClass('active');

      post.find("[id^=shares]").text(data.shares);

    } else {

      post.find("#share-button").removeClass('active');

      post.find("[id^=shares]").text(data.shares);

    }

  });

}

// open post share buttons
function Wo_OpenShareBtns(post_id) {

  post_wrapper = $('#post-' + post_id);

  post_wrapper.find('.post-share').slideToggle(200);

}

// register post comment
function Wo_RegisterComment(text, post_id, user_id, event, page_id) {

  if(event.keyCode == 13 && event.shiftKey == 0) {

    post_wrapper = $('#post-' + post_id);

    comment_textarea = post_wrapper.find('.post-comments');

    comment_btn = comment_textarea.find('.comment-btn');

    textarea_wrapper = comment_textarea.find('.textarea');

    comment_list = post_wrapper.find('.comments-list');

    if(textarea_wrapper.val() == '') {

      return false;

    }

    textarea_wrapper.val('');

    Wo_progressIconLoader(comment_btn);

    $.post(Wo_Ajax_Requests_File() + '?f=posts&s=register_comment', {
      post_id: post_id,
      text: text,
      user_id: user_id,
      page_id: page_id
    }, function (data) {

      if(data.status == 200) {

        post_wrapper.find('.comment-container:first-child').before(data.html);

        post_wrapper.find('#comments').html(data.comments_num);

      }

      Wo_progressIconLoader(comment_btn);

    });

  }

}

// load all post comments
function Wo_loadAllComments(post_id) {

  main_wrapper = $('#post-' + post_id);

  view_more_wrapper = main_wrapper.find('.view-more-wrapper');

  Wo_progressIconLoader(view_more_wrapper);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'load_more_comments',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      main_wrapper.find('.comments-list').html(data.html);

      view_more_wrapper.remove();

    }

  });

}

// show post comments
function Wo_ShowComments(post_id) {

  $('#post-comments-' + post_id).toggleClass('hidden');

}

// open post edit modal
function Wo_OpenPostEditBox(post_id) {

  var edit_box = $('#post-' + post_id).find('#edit-post');

  edit_box.modal({
    show: true
  });

}

// save edited post
function Wo_EditPost(post_id) {

  var post = $('#post-' + post_id);

  var edit_box = $('#post-' + post_id).find('#edit-post');

  var edit_textarea = post.find('.edit-textarea-' + post_id + ' textarea');

  var text = edit_textarea.val();

  var post_text = post.find('.post-description p');

  Wo_progressIconLoader(post.find('#edit-post-button'));

  $.post(Wo_Ajax_Requests_File() + '?f=posts&s=edit_post', {
    post_id: post_id,
    text: text
  }, function (data) {

    if(data.status == 200) {

      post_text.html(data.html);

      edit_box.modal('hide');

    }

    Wo_progressIconLoader(post.find('#edit-post-button'));

  });

}

// open delete post modal
function Wo_OpenPostDeleteBox(post_id) {

  var delete_box = $('#post-' + post_id).find('#delete-post');

  delete_box.modal({
    show: true
  });

}

// delete post
function Wo_DeletePost(post_id) {

  var delete_box = $('#post-' + post_id).find('#delete-post');

  var delete_button = delete_box.find('#delete-all-post');

  Wo_progressIconLoader(delete_button);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'delete_post',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      delete_box.modal('hide');

      setTimeout(function () {

        $('#post-' + post_id).slideUp(200, function () {

          $(this).remove();

        });

      }, 300);

    }

    Wo_progressIconLoader(delete_button);

  });

}

// open comment textarea
function Wo_OpenCommentEditBox(comment_id) {

  comment = $('#comment_' + comment_id);

  comment_text = comment.find('.comment-edit');

  comment_text.slideToggle(100);

}

// save edited comment
function Wo_EditComment(text, comment_id, event) {

  comment = $('#comment_' + comment_id);

  comment_text = comment.find('.comment-text');

  if(event.keyCode == 13 && event.shiftKey == 0) {

    Wo_progressIconLoader(comment.find('#editComment'));

    $.post(Wo_Ajax_Requests_File() + '?f=posts&s=edit_comment', {
      comment_id: comment_id,
      text: text
    }, function (data) {

      if(data.status == 200) {

        comment_text.html(data.html);

        Wo_OpenCommentEditBox(comment_id);

      }

      Wo_progressIconLoader(comment.find('#editComment'));

    });

  }

}

// delete comment
function Wo_DeleteComment(comment_id) {

  var delete_box = $('#comment_' + comment_id).find('#delete-comment');

  var delete_button = delete_box.find('#delete-all-post');

  delete_box.modal({
    show: true
  });

  var comment = $('#comment_' + comment_id);

  delete_button.on('click', function () {

    Wo_progressIconLoader(delete_button);

    $.get(Wo_Ajax_Requests_File(), {
      f: 'posts',
      s: 'delete_comment',
      comment_id: comment_id
    }, function (data) {

      if(data.status == 200) {

        delete_box.modal('hide');

        comment.fadeOut(300, function () {

          $(this).remove();

        });

      }

    });

  });

}

// register comment like
function Wo_RegisterCommentLike(comment_id) {

  var comment = $('#comment_' + comment_id);

  comment_text = comment.find('p.comment-text').text();

  Wo_progressIconLoader(comment.find('#LikeComment'));

  $.post(Wo_Ajax_Requests_File() + '?f=posts&s=register_comment_like', {
    comment_id: comment_id,
    comment_text: comment_text
  }, function (data) {

    if(data.status == 200) {

      comment.find("#LikeComment").html('<i class="fa fa-thumbs-up progress-icon active-like" data-icon="thumbs-up"></i>').fadeIn(250);

      comment.find("#comment-likes").text(data.likes);

    } else {

      comment.find("#LikeComment").html('<i class="fa fa-thumbs-up progress-icon" data-icon="thumbs-up"></i>').fadeIn(250);

      comment.find("#comment-likes").text(data.likes);

    }

  });

}

// register comment wonder
function Wo_RegisterCommentWonder(comment_id) {

  var comment = $('#comment_' + comment_id);

  comment_text = comment.find('p.comment-text').text();

  Wo_progressIconLoader(comment.find('#WonderComment'));

  $.post(Wo_Ajax_Requests_File() + '?f=posts&s=register_comment_wonder', {
    comment_id: comment_id,
    comment_text: comment_text
  }, function (data) {

    if(data.status == 200) {

      comment.find("#WonderComment").html('<span class="active-wonder"><i class="fa fa-exclamation-circle progress-icon" data-icon="exclamation-circle"></i></span>').fadeIn(250);

      comment.find("#comment-wonders").text(data.wonders);

    } else {

      comment.find("#WonderComment").html('<i class="fa fa-exclamation-circle progress-icon" data-icon="exclamation-circle"></i>').fadeIn(250);

      comment.find("#comment-wonders").text(data.wonders);
    }

  });

}

// save post
function Wo_SavePost(post_id) {

  var post = $('#post-' + post_id);

  Wo_progressIconLoader(post.find('.save-post'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'save_post',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      post.find('.save-post').html('<i class="fa fa-check progress-icon" data-icon="floppy-o"></i> ' + data.text);

    } else if(data.status == 300) {

      post.find('.save-post').html('<i class="fa fa-floppy-o progress-icon" data-icon="check"></i> ' + data.text);

    }

  });

}

// report post
function Wo_ReportPost(post_id) {

  var post = $('#post-' + post_id);

  Wo_progressIconLoader(post.find('.report-post'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'report_post',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      post.find('.report-post').html('<i class="fa fa-check progress-icon" data-icon="flag"></i> ' + data.text);

    } else if(data.status == 300) {

      post.find('.report-post').html('<i class="fa fa-flag progress-icon" data-icon="flag"></i> ' + data.text);

    }

  });

}


function Wo_PinPost(post_id, id) {

  var post = $('#post-' + post_id);
  var page = 0;
  var page_id = 0;

  if(id != 0) {
    page_id = id;
    page = 'page';
  }
  Wo_progressIconLoader(post.find('.pin-post'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'pin_post',
    post_id: post_id,
    page_id: page_id,
    page: page
  }, function (data) {

    if(data.status == 200) {

      post.find('.pin-post').html('<i class="fa fa-thumb-tack progress-icon pinned-text" data-icon="thumb-tack"></i> ' + data.text);

    } else if(data.status == 300) {

      post.find('.pin-post').html('<i class="fa fa-thumb-tack progress-icon" data-icon="thumb-tack"></i> ' + data.text);

    }

  });


}
// open post liked users
function Wo_OpenPostLikedUsers(post_id) {

  var post = $('#post-' + post_id);

  post_likes_container = post.find('.post-likes');

  post.find('.post-wonders').slideUp(200, function () {

    post.find('.post-wonders').empty();

  });

  if(!post_likes_container.is(':empty')) {

    post_likes_container.slideToggle(200, function () {

      post.find('.post-likes').empty();

    });

    return false;

  }

  Wo_progressIconLoader(post.find('.post-like-status'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'get_post_likes',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      if(data.html.length == 0) {

        post_likes_container.html('<span class="view-more-wrapper">' + data.message + '</span>');

      } else {

        post_likes_container.html(data.html);

      }

      post_likes_container.slideToggle(200);

    }

    Wo_progressIconLoader(post.find('.post-like-status'));

  });

}

// open post wodered users
function Wo_OpenPostWonderedUsers(post_id) {

  var post = $('#post-' + post_id);

  post_wonders_container = post.find('.post-wonders');

  post.find('.post-likes').slideUp(200, function () {

    post.find('.post-likes').empty();

  });



  if(!post_wonders_container.is(':empty')) {

    post_wonders_container.slideToggle(200, function () {

      post.find('.post-wonders').empty();

    });

    return false;

  }

  Wo_progressIconLoader(post.find('.post-wonders-status'));

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'get_post_wonders',
    post_id: post_id
  }, function (data) {

    if(data.status == 200) {

      if(data.html.length == 0) {

        post_wonders_container.html('<span class="view-more-wrapper">' + data.message + '</span>');

      } else {

        post_wonders_container.html(data.html);

      }

      post_wonders_container.slideToggle(200);

    }

    Wo_progressIconLoader(post.find('.post-wonders-status'));

  });

}

// add emo to input
function Wo_AddEmo(code, input) {

  inputTag = $(input);

  inputVal = inputTag.val();

  if(typeof (inputTag.attr('placeholder')) != "undefined") {

    inputPlaceholder = inputTag.attr('placeholder');

    if(inputPlaceholder == inputVal) {

      inputTag.val('');

      inputVal = inputTag.val();

    }

  }

  if(inputVal.length == 0) {

    inputTag.val(code + ' ');

  } else {

    inputTag.val(inputVal + ' ' + code);

  }

  inputTag.keyup();

}

// accept follow request
function Wo_AcceptFollowRequest(user_id) {

  var main_container = $('.user-follow-request-' + user_id);

  var follow_main_container = main_container.find('#accept-' + user_id);

  Wo_progressIconLoader(follow_main_container);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'accept_follow_request',
    following_id: user_id
  }, function (data) {

    if(data.status == 200) {

      main_container.find('.accept-btns').html(data.html);

    }

  });

}

// delete follow request
function Wo_DeleteFollowRequest(user_id) {

  var main_container = $('.user-follow-request-' + user_id);

  var follow_main_container = main_container.find('#delete-' + user_id);

  Wo_progressIconLoader(follow_main_container);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'delete_follow_request',
    following_id: user_id
  }, function (data) {

    if(data.status == 200) {

      main_container.find('.accept-btns').html(data.html);

    }

  });

}

// update post privacy
function Wo_UpdatePostPrivacy(post_id, privacy_type, event) {

  var post = $('#post-' + post_id);

  event.preventDefault();

  var post_privacy_container = post.find('.post-privacy');

  Wo_progressIconLoader(post_privacy_container);

  $.get(Wo_Ajax_Requests_File(), {
    f: 'posts',
    s: 'update_post_privacy',
    post_id: post_id,
    privacy_type: privacy_type
  }, function (data) {

    if(data.status == 200) {

      if(data.privacy_type == 0) {

        post_privacy_container.html('<i class="fa fa-globe progress-icon" data-icon="globe"></i>');

      } else if(data.privacy_type == 1) {

        post_privacy_container.html('<i class="fa fa-users progress-icon" data-icon="users"></i>');

      } else if(data.privacy_type == 2) {

        post_privacy_container.html('<i class="fa fa-user progress-icon" data-icon="user"></i>');

      } else if(data.privacy_type == 3) {

        post_privacy_container.html('<i class="fa fa-lock progress-icon" data-icon="lock"></i>');

      } else {

        return false;

      }

    }

  });

}

// open chat tab
function Wo_OpenChatTab(recipient_id) {

  $.get(Wo_Ajax_Requests_File(), {
    f: 'chat',
    s: 'is_chat_on',
    recipient_id: recipient_id
  }, function (data) {

    if(data.chat != 1) {

      document.location = data.url;

      return false;

    }

  });

  if(current_width < 720) {

    $.get(Wo_Ajax_Requests_File(), {
      f: 'chat',
      s: 'close',
      recipient_id: recipient_id
    }, function (data) {

      document.location = data.url;

    });

    return false;

  }

  chat_container = $('.chat-container');

  $(document.body).attr('data-chat-recipient', recipient_id);

  $('.chat-wrapper').show();

  $.get(Wo_Ajax_Requests_File(), {
    f: 'chat',
    s: 'load_chat_tab',
    recipient_id: recipient_id
  }, function (data) {

    if(data.status == 200) {

      $('.chat-wrapper').remove();

      $('.chat-tab').html(data.html);

      $('.chat-wrapper').show();

      $('.chat-textarea textarea').keyup();

      $('#online_' + recipient_id).find('.new-message-alert').hide();

      $.get(Wo_Ajax_Requests_File(), {
        f: 'chat',
        s: 'load_chat_messages',
        recipient_id: recipient_id
      }, function (data) {

        $('.chat-tab').find('.chat-messages').html(data.messages);

        setTimeout(function () {

          $('.chat-messages-wrapper').scrollTop($('.chat-messages-wrapper')[0].scrollHeight);

        }, 300);

      });

    }

  });

}

function Wo_OpenChatUsersTab() {
  $('.online-content-toggler').slideToggle(150);
  $.get(Wo_Ajax_Requests_File(), {
    f: 'chat',
    s: 'open_tab'
  });
}

function Wo_SearchForPosts(query) {
  var type = '';

  if ($('.page-margin').attr('data-page') == "timeline") {
    type = 'user';
  } else if ($('.page-margin').attr('data-page') == "page"){
    type = 'page';
  } else {
    return false;
  }
  Wo_progressIconLoader($('.search-for-posts-container'));
  var id = $('.page-margin').attr('data-id');
  if (id == null || id == "undefined") {
    return false;
  }
  $.get(Wo_Ajax_Requests_File(), {f:'posts', s:'search_for_posts', id: id, search_query: query, type: type}, function (data) {

     if (data.status == 200) {
        $('#posts').html(data.html);
     }
     
     Wo_progressIconLoader($('.search-for-posts-container'));
  });
  
}

function Wo_Fetch(id, post_id) {
   var clickedOnBody = true;
   var user_from_post_id = '#post-' + post_id;
   var user_from_image = '#post-' + post_id + ' .post-heading';
   var div = '.user-fetch-post-' + post_id + '-user-' + id;
   var bla = user_from_post_id + ', ' + div;

   clearTimeout(timeout);
   $(div).fadeIn(200);
         
   var timeout;
   function hidepanel() {
     $(div).fadeOut(0); 
   }
    $(div).mouseleave(doTimeout);
    $(user_from_image).mouseleave(doTimeout);


     function doTimeout(){
        clearTimeout(timeout);
        timeout = setTimeout(hidepanel, 0);
     }
}