<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (WoWonder)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/wowondersocial
// | @author_email: deendoughouz@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - A Social Networking Platform
// | Copyright (c) 2015 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
require_once( "assets/import/hybridauth/Hybrid/Auth.php" );
require_once( "assets/import/hybridauth/Hybrid/Endpoint.php" );
Hybrid_Endpoint::process();