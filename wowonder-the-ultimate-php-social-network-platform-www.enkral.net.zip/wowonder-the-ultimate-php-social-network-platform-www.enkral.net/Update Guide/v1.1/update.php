<?php 
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (WoWonder)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/wowondersocial
// | @author_email: deendoughouz@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - A Social Networking Platform
// | Copyright (c) 2015 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
if (file_exists('assets/init.php')) {
	require 'assets/init.php';
} else {
	die('Please put this file in the home directory !');
}


$query = "CREATE TABLE IF NOT EXISTS `Wo_Pages` (
`page_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_name` varchar(32) NOT NULL,
  `page_title` varchar(32) NOT NULL,
  `page_description` varchar(1000) NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'upload/photos/d-page.jpg',
  `cover` varchar(255) NOT NULL DEFAULT 'upload/photos/d-cover.jpg',
  `page_category` int(11) NOT NULL DEFAULT '1',
  `website` varchar(255) NOT NULL,
  `facebook` varchar(32) NOT NULL,
  `google` varchar(32) NOT NULL,
  `vk` varchar(32) NOT NULL,
  `twitter` varchar(32) NOT NULL,
  `linkedin` varchar(32) NOT NULL,
  `company` varchar(32) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `address` varchar(100) NOT NULL,
  `instgram` varchar(32) NOT NULL,
  `youtube` varchar(100) NOT NULL,
  `verified` enum('0','1') NOT NULL DEFAULT '0',
  `active` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Pages_Likes` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;

ALTER TABLE `Wo_Pages`
 ADD PRIMARY KEY (`page_id`), ADD KEY `page_id` (`page_id`,`page_category`);

ALTER TABLE `Wo_Pages_Likes`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`,`user_id`,`page_id`);

ALTER TABLE `Wo_Pages`
MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=0;

ALTER TABLE `Wo_Pages_Likes`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=0;

ALTER TABLE `Wo_Posts` ADD `page_id` INT NOT NULL AFTER `postText`, ADD `postLink` VARCHAR(100) NOT NULL AFTER `page_id`, ADD `postLinkTitle` VARCHAR(100) NOT NULL AFTER `postLink`, ADD `postLinkImage` VARCHAR(100) NOT NULL AFTER `postLinkTitle`, ADD `postLinkContent` VARCHAR(500) NOT NULL AFTER `postLinkImage`, ADD `postVimeo` VARCHAR(100) NOT NULL AFTER `postLinkContent`, ADD `postDailymotion` VARCHAR(100) NOT NULL AFTER `postVimeo`, ADD `postFacebook` VARCHAR(100) NOT NULL AFTER `postDailymotion`, ADD INDEX (`page_id`) ;
ALTER TABLE `Wo_Users` ADD `background_image` VARCHAR(100) NOT NULL AFTER `cover`, ADD `background_image_status` ENUM('0','1') NOT NULL AFTER `background_image`, ADD `relationship_id` INT NOT NULL AFTER `background_image_status`, ADD `address` VARCHAR(100) NOT NULL AFTER `relationship_id`, ADD `working` VARCHAR(32) NOT NULL AFTER `address`, ADD `working_link` VARCHAR(32) NOT NULL AFTER `working`;
ALTER TABLE `Wo_Comments` ADD `page_id` INT NOT NULL AFTER `user_id`, ADD INDEX (`page_id`);
ALTER TABLE `Wo_Notifications` ADD `page_id` INT NOT NULL AFTER `post_id`, ADD INDEX (`page_id`);
ALTER TABLE `Wo_PinnedPosts` ADD `page_id` INT NOT NULL AFTER `user_id`, ADD INDEX (`page_id`) ;";

$query = mysqli_multi_query($sqlConnect, $query);

if ($query) {
	@rmdir('themes/' . $config['theme'] .  '/stylesheet/font-awesome-4.4.0');
  @session_destroy();
	header("Location: " . Wo_SeoLink('index.php?tab1=welcome'));
	exit();
}
?>