<?php 
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.wowonder.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com   
// +------------------------------------------------------------------------+
// | WoWonder - The Ultimate Social Networking Platform
// | Copyright (c) 2016 WoWonder. All rights reserved.
// +------------------------------------------------------------------------+
if (file_exists('assets/init.php')) {
	require 'assets/init.php';
} else {
	die('Please put this file in the home directory !');
}


$query = "CREATE TABLE IF NOT EXISTS `Wo_Albums_Media` (
`id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `Wo_Banned_Ip` (
`id` int(11) NOT NULL,
  `ip_address` varchar(32) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Comment_Replies` (
`id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `Wo_Comment_Replies_Likes` (
  `id` int(11) NOT NULL,
  `reply_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `Wo_Comment_Replies_Wonders` (
`id` int(11) NOT NULL,
  `reply_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Games` (
`id` int(11) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `game_avatar` varchar(100) NOT NULL,
  `game_link` varchar(100) NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Games_Players` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `last_play` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Groups` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_name` varchar(32) NOT NULL,
  `group_title` varchar(32) NOT NULL,
  `avatar` varchar(120) NOT NULL DEFAULT 'upload/photos/d-group.jpg ',
  `cover` varchar(120) NOT NULL DEFAULT 'upload/photos/d-cover.jpg  ',
  `about` varchar(550) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '1',
  `privacy` enum('1','2') NOT NULL DEFAULT '1',
  `join_privacy` enum('1','2') NOT NULL DEFAULT '1',
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `registered` varchar(32) NOT NULL DEFAULT '0/0000'
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Group_Members` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `active` enum('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Pages_Invites` (
`id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `inviter_id` int(11) NOT NULL,
  `invited_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `Wo_RecentSearches` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `search_id` int(11) NOT NULL,
  `search_type` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `Wo_Verification_Requests` (
`id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  `type` varchar(32) NOT NULL,
  `seen` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

ALTER TABLE `Wo_Albums_Media`
 ADD PRIMARY KEY (`id`), ADD KEY `post_id` (`post_id`);

ALTER TABLE `Wo_Banned_Ip`
 ADD PRIMARY KEY (`id`), ADD KEY `ip_address` (`ip_address`);

ALTER TABLE `Wo_Comment_Replies`
 ADD PRIMARY KEY (`id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `user_id` (`user_id`,`page_id`);


ALTER TABLE `Wo_Comment_Replies_Wonders`
 ADD PRIMARY KEY (`id`), ADD KEY `reply_id` (`reply_id`,`user_id`);

ALTER TABLE `Wo_Games`
 ADD PRIMARY KEY (`id`), ADD KEY `active` (`active`);


ALTER TABLE `Wo_Games_Players`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`,`game_id`,`active`);


ALTER TABLE `Wo_Groups`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `privacy` (`privacy`);


ALTER TABLE `Wo_Group_Members`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`,`group_id`);


ALTER TABLE `Wo_Pages_Invites`
 ADD PRIMARY KEY (`id`), ADD KEY `page_id` (`page_id`,`inviter_id`,`invited_id`);

ALTER TABLE `Wo_RecentSearches`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`,`search_id`), ADD KEY `search_type` (`search_type`);

ALTER TABLE `Wo_Verification_Requests`
 ADD PRIMARY KEY (`id`), ADD KEY `user_id` (`user_id`), ADD KEY `page_id` (`page_id`);

ALTER TABLE `Wo_Albums_Media`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Banned_Ip`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Comment_Replies`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Comment_Replies_Wonders`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Games`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Games_Players`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Groups`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Group_Members`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Pages_Invites`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_RecentSearches`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `Wo_Verification_Requests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

CREATE TABLE IF NOT EXISTS `Wo_Config` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8;

INSERT INTO `Wo_Config` (`id`, `name`, `value`) VALUES
(1, 'siteName', '" . Wo_Secure($wo['config']['siteName']) . "'),
(2, 'siteTitle', '" . Wo_Secure($wo['config']['siteTitle']) . "'),
(3, 'siteKeywords', '" . Wo_Secure($wo['config']['siteKeywords']) . "'),
(4, 'siteDesc', '" . Wo_Secure($wo['config']['siteDesc']) . "'),
(5, 'siteEmail', '" . Wo_Secure($wo['config']['siteEmail']) . "'),
(6, 'defualtLang', '" . Wo_Secure($wo['config']['defualtLang']) . "'),
(7, 'emailValidation', '" . Wo_Secure($wo['config']['emailValidation']) . "'),
(8, 'emailNotification', '" . Wo_Secure($wo['config']['emailNotification']) . "'),
(9, 'fileSharing', '" . Wo_Secure($wo['config']['fileSharing']) . "'),
(10, 'seoLink', '" . Wo_Secure($wo['config']['seoLink']) . "'),
(11, 'cacheSystem', '" . Wo_Secure($wo['config']['cacheSystem']) . "'),
(12, 'chatSystem', '" . Wo_Secure($wo['config']['chatSystem']) . "'),
(13, 'useSeoFrindly', '" . Wo_Secure($wo['config']['useSeoFrindly']) . "'),
(14, 'reCaptcha', '" . Wo_Secure($wo['config']['reCaptcha']) . "'),
(15, 'reCaptchaKey', '" . Wo_Secure($wo['config']['reCaptchaKey']) . "'),
(16, 'user_lastseen', '" . Wo_Secure($wo['config']['user_lastseen']) . "'),
(17, 'age', '" . Wo_Secure($wo['config']['age']) . "'),
(18, 'deleteAccount', '" . Wo_Secure($wo['config']['deleteAccount']) . "'),
(19, 'connectivitySystem', '" . Wo_Secure($wo['config']['connectivitySystem']) . "'),
(20, 'profileVisit', '" . Wo_Secure($wo['config']['profileVisit']) . "'),
(21, 'maxUpload', '" . Wo_Secure($wo['config']['maxUpload']) . "'),
(22, 'maxCharacters', '" . Wo_Secure($wo['config']['maxCharacters']) . "'),
(23, 'message_seen', '" . Wo_Secure($wo['config']['message_seen']) . "'),
(24, 'message_typing', '" . Wo_Secure($wo['config']['message_typing']) . "'),
(25, 'google_map_api', 'AIzaSyBOfpaMO_tMMsuvS2T4zx4llbtsFqMuT9Y'),
(26, 'allowedExtenstion', '" . Wo_Secure($wo['config']['allowedExtenstion']) . "'),
(27, 'censored_words', '" . $wo['config']['censored_words'] . "'),
(28, 'googleAnalytics', ''),
(29, 'AllLogin', '" . Wo_Secure($wo['config']['AllLogin']) . "'),
(30, 'googleLogin', '" . Wo_Secure($wo['config']['googleLogin']) . "'),
(31, 'facebookLogin', '" . Wo_Secure($wo['config']['facebookLogin']) . "'),
(32, 'twitterLogin', '" . Wo_Secure($wo['config']['twitterLogin']) . "'),
(33, 'linkedinLogin', '" . Wo_Secure($wo['config']['linkedinLogin']) . "'),
(34, 'VkontakteLogin', '" . Wo_Secure($wo['config']['VkontakteLogin']) . "'),
(35, 'facebookAppId', '" . Wo_Secure($wo['config']['facebookAppId']) . "'),
(36, 'facebookAppKey', '" . Wo_Secure($wo['config']['facebookAppKey']) . "'),
(37, 'googleAppId', '" . Wo_Secure($wo['config']['googleAppId']) . "'),
(38, 'googleAppKey', '" . Wo_Secure($wo['config']['googleAppKey']) . "'),
(39, 'twitterAppId', '" . Wo_Secure($wo['config']['twitterAppId']) . "'),
(40, 'twitterAppKey', '" . Wo_Secure($wo['config']['twitterAppKey']) . "'),
(41, 'linkedinAppId', '" . Wo_Secure($wo['config']['linkedinAppId']) . "'),
(42, 'linkedinAppKey', '" . Wo_Secure($wo['config']['linkedinAppKey']) . "'),
(43, 'VkontakteAppId', '" . Wo_Secure($wo['config']['VkontakteAppId']) . "'),
(44, 'VkontakteAppKey', '" . Wo_Secure($wo['config']['VkontakteAppKey']) . "'),
(45, 'theme', 'wowonder'),
(47, 'second_post_button', 'wonder'),
(48, 'instagramAppId', ''),
(49, 'instagramAppkey', ''),
(50, 'instagramLogin', '1'),
(51, 'header_background', '#444444'),
(52, 'header_hover_border', '#666666'),
(53, 'header_color', '#ffffff'),
(54, 'body_background', '#f9f9f9'),
(55, 'btn_color', '#ffffff'),
(56, 'btn_background_color', '#a84849'),
(57, 'btn_hover_color', '#ffffff'),
(58, 'btn_hover_background_color', '#c45a5b'),
(59, 'setting_header_color', '#ffffff'),
(60, 'setting_header_background', '#a84849'),
(61, 'setting_active_sidebar_color', '#ffffff'),
(62, 'setting_active_sidebar_background', '#a84849'),
(63, 'setting_sidebar_background', '#ffffff'),
(64, 'setting_sidebar_color', '#444444'),
(65, 'logo_extension', 'png'),
(66, 'online_sidebar', '1');

ALTER TABLE `Wo_Config`
 ADD PRIMARY KEY (`id`);

ALTER TABLE `Wo_Config`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=67;

ALTER TABLE `Wo_Notifications` ADD `group_id` INT NOT NULL AFTER `page_id`, ADD `seen_pop` INT NOT NULL AFTER `group_id`, ADD INDEX (`group_id`, `seen_pop`);

ALTER TABLE `Wo_Pages` ADD `call_action_type` INT NOT NULL AFTER `address`, ADD `call_action_type_url` VARCHAR(255) NOT NULL AFTER `call_action_type`;

ALTER TABLE `Wo_Pages` ADD `registered` VARCHAR(32) NOT NULL DEFAULT '0/0000' AFTER `active`, ADD INDEX (`registered`);

ALTER TABLE `Wo_Pages` ADD INDEX( `user_id`, `page_name`, `verified`, `active`);

ALTER TABLE `Wo_Pages_Likes` ADD INDEX( `active`);

ALTER TABLE `Wo_PinnedPosts` ADD `group_id` INT NOT NULL AFTER `page_id`, ADD INDEX (`group_id`) ;

ALTER TABLE `Wo_Posts` ADD `group_id` INT NOT NULL AFTER `page_id`, ADD INDEX (`group_id`) ;

ALTER TABLE `Wo_Posts` ADD `postFeeling` VARCHAR(255) NOT NULL AFTER `postType`, ADD `postListening` VARCHAR(255) NOT NULL AFTER `postFeeling`, ADD `postTraveling` VARCHAR(255) NOT NULL AFTER `postListening`, ADD `postWatching` VARCHAR(255) NOT NULL AFTER `postTraveling`, ADD `postPlaying` VARCHAR(255) NOT NULL AFTER `postWatching`;

ALTER TABLE `Wo_Posts` ADD `registered` VARCHAR(32) NOT NULL DEFAULT '0/0000' AFTER `time`, ADD `album_name` VARCHAR(52) NOT NULL AFTER `registered`, ADD `multi_image` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `album_name`, ADD INDEX (`registered`) ;

ALTER TABLE `Wo_Users` ADD `school` VARCHAR(32) NOT NULL AFTER `about`;

ALTER TABLE `Wo_Users` ADD `instagram` VARCHAR(32) NOT NULL AFTER `vk`;

ALTER TABLE `Wo_Users` ADD `ip_address` VARCHAR(32) NOT NULL AFTER `src`;

ALTER TABLE `Wo_Users` ADD `birth_privacy` ENUM('0','1','2') NOT NULL DEFAULT '0' AFTER `show_activities_privacy`, ADD `visit_privacy` ENUM('0','1') NOT NULL DEFAULT '0' AFTER `birth_privacy`;

ALTER TABLE `Wo_Users` ADD `e_liked` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `emailNotification`, ADD `e_wondered` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_liked`, ADD `e_shared` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_wondered`, ADD `e_followed` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_shared`, ADD `e_commented` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_followed`, ADD `e_visited` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_commented`, ADD `e_liked_page` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_visited`, ADD `e_mentioned` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_liked_page`, ADD `e_joined_group` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_mentioned`, ADD `e_accepted` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_joined_group`, ADD `e_profile_wall_post` ENUM('0','1') NOT NULL DEFAULT '1' AFTER `e_accepted`;

ALTER TABLE `Wo_Users` ADD `registered` VARCHAR(32) NOT NULL DEFAULT '0/0000' AFTER `type`, ADD INDEX (`registered`) ;";

$query = mysqli_multi_query($sqlConnect, $query);

if ($query) {
  echo 'Done! now please upload and overwrite ALL files/folders located inside "Script" folder to your server.';
	exit();
}
?>